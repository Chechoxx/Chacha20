
#include <iostream>
//#include "sodium.h"

#define R(a,b) (((a) << (b)) | ((a) >> (32 - (b))))
void chacha20_rounds(uint32_t* x) {
    //Este ciclo realiza las rondas
    for (int i = 0; i < 10; i++) {
        // Rondas (0,4,8,12), (1,5,9,13), (2,6,10,14), (3,7,11,15)
        x[0] += x[4]; 
        x[12] ^= x[0]; 
        x[12] = R(x[12], 16); 
        x[8] += x[12]; 
        x[4] ^= x[8];
        x[4] = R(x[4], 12);
        x[0] += x[4]; 
        x[12] ^= x[0];
        x[12] = R(x[12], 8);
        x[8] += x[12]; 
        x[4] ^= x[8]; 
        x[4] = R(x[4], 7);

        x[1] += x[5]; 
        x[13] ^= x[1]; 
        x[13] = R(x[13], 16);
        x[9] += x[13];
        x[5] ^= x[9]; 
        x[5] = R(x[5], 12);
        x[1] += x[5]; 
        x[13] ^= x[1]; 
        x[13] = R(x[13], 8);
        x[9] += x[13];
        x[5] ^= x[9]; 
        x[5] = R(x[5], 7);

        
        x[2] += x[6]; 
        x[14] ^= x[2]; 
        x[14] = R(x[14], 16);
        x[10] += x[14]; 
        x[6] ^= x[10]; 
        x[6] = R(x[6], 12);
        x[2] += x[6]; 
        x[14] ^= x[2]; 
        x[14] = R(x[14], 8);
        x[10] += x[14]; 
        x[6] ^= x[10]; 
        x[6] = R(x[6], 7);

        x[3] += x[7]; 
        x[15] ^= x[3]; 
        x[15] = R(x[15], 16);
        x[11] += x[15]; 
        x[7] ^= x[11]; 
        x[7] = R(x[7], 12);
        x[3] += x[7]; 
        x[15] ^= x[3]; 
        x[15] = R(x[15], 8);
        x[11] += x[15]; 
        x[7] ^= x[11]; 
        x[7] = R(x[7], 7);

        // Rondas (0,5,10,15), (1,6,11,12), (2,7,8,13), (3,4,9,14)
        x[0] += x[5]; 
        x[15] ^= x[0]; 
        x[15] = R(x[15], 16);
        x[10] += x[15];
        x[5] ^= x[10]; 
        x[5] = R(x[5], 12);
        x[0] += x[5]; 
        x[15] ^= x[0]; 
        x[15] = R(x[15], 8);
        x[10] += x[15]; 
        x[5] ^= x[10]; 
        x[5] = R(x[5], 7);

        x[1] += x[6]; 
        x[12] ^= x[1]; 
        x[12] = R(x[12], 16);
        x[11] += x[12]; 
        x[6] ^= x[11];
        x[6] = R(x[6], 12);
        x[1] += x[6]; 
        x[12] ^= x[1];
        x[12] = R(x[12], 8);
        x[11] += x[12]; 
        x[6] ^= x[11]; 
        x[6] = R(x[6], 7);

        x[2] += x[7]; 
        x[13] ^= x[2]; 
        x[13] = R(x[13], 16);
        x[8] += x[13]; 
        x[7] ^= x[8]; 
        x[7] = R(x[7], 12);
        x[2] += x[7]; 
        x[13] ^= x[2]; 
        x[13] = R(x[13], 8);
        x[8] += x[13];
        x[7] ^= x[8]; 
        x[7] = R(x[7], 7);

        x[3] += x[4]; 
        x[14] ^= x[3]; 
        x[14] = R(x[14], 16);
        x[9] += x[14]; 
        x[4] ^= x[9]; 
        x[4] = R(x[4], 12);
        x[3] += x[4]; 
        x[14] ^= x[3]; 
        x[14] = R(x[14], 8);
        x[9] += x[14]; 
        x[4] ^= x[9]; 
        x[4] = R(x[4], 7);
    }
}

void chacha20_enc(const uint8_t* plaintext, uint8_t* ciphertext, size_t len, const uint32_t key[8], const uint32_t nonce[3]) {

    //Arreglo de inicialización de chacha20 input, k es la clave,  
    uint32_t x[16] = {0x61707865,0x3320646e,0x79622d32,0x6b206574,key[0],key[1],key[2],key[3],nonce[0],nonce[1],nonce[2],0,0,0,0,0};

    for (size_t i = 0; i < len; i++) {
        if (i % 64 == 0) {
            uint32_t aux[16];
            memcpy(aux, x, sizeof(x));
            chacha20_rounds(aux);
            for (int j = 0; j < 16; j++) {
                x[j] += aux[j];
            }
        }
        ciphertext[i] = plaintext[i] ^ (x[(i / 64) * 16 + (i % 64) / 4] >> ((i % 4) * 8) & 0xFF);
    }
}


int main(void) {
    /*
	unsigned char buf[256];
	if (sodium_init() == -1) {
		return 1;
	}
	std::cout << "Generación de aleatorios con Lipsodium\n";
	randombytes_buf(buf, sizeof((buf)));
	printf("%lu\n", sizeof(buf));
	for (int i = 0; i < sizeof(buf); i++)
		printf("%02x ", (unsigned int)buf[i]);
	printf("\n");   */

    uint32_t key[8] = { 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07 };
    uint32_t nonce[3] = { 0x00, 0x01, 0x02 };  // vector de inicialización
    const char* mensaje = "hola mundo";  //Mensaje que se quiere cifrar

    size_t len = strlen(mensaje);
    uint8_t ciphertext[sizeof(mensaje)];

    printf("Mensaje: ");
    for (size_t i = 0; i < len; i++) {
        printf("%02x ", mensaje[i]);
    }
    printf("\n");

    

    chacha20_enc((const uint8_t*)mensaje, ciphertext, len, key, nonce); //función que se encarga del cifrado

    printf("Mensaje cifrado: ");
    for (size_t i = 0; i < len; i++) {
        printf("%02x ", ciphertext[i]);
    }
    printf("\n");

    return 0;



 }


